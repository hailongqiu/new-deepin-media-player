#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (C) 2012 Deepin, Inc.
#               2012 Hailong Qiu
#
# Author:     Hailong Qiu <356752238@qq.com>
# Maintainer: Hailong Qiu <356752238@qq.com>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

from dtk.ui.trayicon import TrayIcon
from skin import app_theme
from locales import _
import gtk

class LdmpTrayIcon(object):
    def __init__(self):
        self.logo_pixbuf = app_theme.get_pixbuf("logo.png")
        self.main_vbox = gtk.VBox()
        
    def init_values(self, this, gui, ldmp):
        # init.
        self.this = this
        self.gui = gui
        self.ldmp = ldmp
        # 托盘.
        self.trayicon = TrayIcon()
        self.trayicon.set_size_request(200, 300)
        self.trayicon.set_from_pixbuf(self.logo_pixbuf.get_pixbuf())
        self.trayicon.set_tooltip_text(_("深度影音"))
        self.trayicon.add_widget(self.main_vbox)
        
    def auto(self): 
        return True
		  
    def start(self):
        self.trayicon.set_visible(True)
        
    def stop(self): 
        self.trayicon.set_visible(False)
		  
    def name(self): 
        return "deepin_media_player_tray_icon" 
		  
    def insert(self): 
        return None
		  
    def icon(self): 
        return None
		  
    def version(self):
        return "2.0"
    
    def author(self):
        return "hailongqiu"
	  
	  
def return_plugin(): 
    return LdmpTrayIcon
